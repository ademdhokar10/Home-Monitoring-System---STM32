# Video link: https://youtu.be/OAV-FWFhPZQ
![Home Monitor With Login System - STM32](https://github.com/user-attachments/assets/151de5e7-75d8-4e48-9af6-175306c958b8)
